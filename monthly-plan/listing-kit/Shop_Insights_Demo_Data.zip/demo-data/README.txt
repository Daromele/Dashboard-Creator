Demo files for Shop Insights: three made-up Etsy shops, January 2025 to September 27, 2026.
Every name, address and number is invented. The files use Etsy's own export layouts.

Import each shop's folder into its own shop (Import files → choose or add the shop → drop the whole folder's files):
  Fern & Fable Prints: 21 monthly statements, 2414 orders, 23 listings, 699 reviews, 90 payouts
  Copper Kiln Ceramics: 21 monthly statements, 720 orders, 13 listings, 213 reviews, 89 payouts
  Plan & Page Studio: 21 monthly statements, 4582 orders, 24 listings, 1338 reviews, 90 payouts

Where each file comes from on Etsy:
  etsy_statement_YYYY_M.csv   Shop Manager → Finances → Monthly statements → Download CSV (one per month)
  EtsySoldOrderItems YYYY.csv Shop Manager → Settings → Options → Download Data → Order Items
  EtsyListingsDownload.csv    Shop Manager → Settings → Options → Download Data → Listings
  reviews.json                Your account → Privacy settings → Download data
  EtsyDeposits YYYY.csv       Shop Manager → Settings → Options → Download Data → Etsy Payments Deposits
